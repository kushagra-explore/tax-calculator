self.__precacheManifest = [
  {
    "revision": "fb2967db0ccaad39bcc41db4ec5271f7",
    "url": "/pwa/public/js/CollegePredictorMobile.c16d0df69bbbaa023868.js"
  },
  {
    "revision": "237c10bd15f2253767087c8e914c08ba",
    "url": "/pwa/public/js/Youtube.b7d3e3a419fe644d383f.js"
  },
  {
    "revision": "b8d7287c55e817581d030c021b5bbd2a",
    "url": "/pwa/public/js/videofold.595b441f3a519c340b3d.css"
  },
  {
    "revision": "d9e9b346f2e34d76db801d3a1a297640",
    "url": "/pwa/public/js/videofold.11ea5cff892bd2033c50.js"
  },
  {
    "revision": "8967ad5136e9a13b41ac6a1c6beac87f",
    "url": "/pwa/public/js/vendors.ce402ac7b5cc9ce7b1b3.js"
  },
  {
    "revision": "2a209555a526f8718cc828f692f9860b",
    "url": "/pwa/public/js/searchLayer.832e0ac31c9f5e83e0cf.js"
  },
  {
    "revision": "97feb2bd01e42e51af4de0cd7a8dd69b",
    "url": "/pwa/public/js/searchLayer.5c6de3d305d54608cbeb.css"
  },
  {
    "revision": "a3b877877f6410deca5fe62091e9e274",
    "url": "/pwa/public/js/rightpanel.702cdabb147fc8e2a929.js"
  },
  {
    "revision": "9a5be0f26d989c13fdf7338d703e173a",
    "url": "/pwa/public/js/rightpanel.13769b2fdc2ead860b69.css"
  },
  {
    "revision": "34c91182c829243e8de321ee9fd17a89",
    "url": "/pwa/public/js/recolayer.4a6666e080fbf30c03b5.css"
  },
  {
    "revision": "dacf7f475dff185172e51a4a7359adc4",
    "url": "/pwa/public/js/recolayer.487345075f5de446d99a.js"
  },
  {
    "revision": "2c6ff3eda75b95289a26e165f0788789",
    "url": "/pwa/public/js/rankingPageMobile.a9cf854ef8d8206b4105.js"
  },
  {
    "revision": "3eb14f3838ada50e10f062a895c3b9cf",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff"
  },
  {
    "revision": "1a5a7a1706f02d39b484860f3bf538e7",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-600.svg"
  },
  {
    "revision": "49fbe77658d29a343cd06b5245be483e",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-600.woff"
  },
  {
    "revision": "c0e9eb34c80900aaacc306b011e1ee3c",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-700.svg"
  },
  {
    "revision": "72862e7cf19603ad24f26baf86dd0e08",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-700.woff"
  },
  {
    "revision": "904e2fa237dbd34b9e283f86060730cd",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-800.svg"
  },
  {
    "revision": "ceceedfc9f46fa98883ec9623d01dc09",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-800.woff"
  },
  {
    "revision": "7e735d7ae17da9ead1360165b1dc3cfb",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-regular.svg"
  },
  {
    "revision": "ce659615885f33d928eb7fe276574106",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/open-sans-v13-latin-regular.woff"
  },
  {
    "revision": "2de372d1aa20c26a2deae6fc3500ba6a",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/OpenSans-SemiBold.svg"
  },
  {
    "revision": "2c11b48f25348fbf913c3a54d9caa243",
    "url": "https://images.shiksha.ws/pwa/public/fonts/open-sans/OpenSans-SemiBold.woff"
  },
  {
    "revision": "da774703acf5357c7fbb9633e0e83667",
    "url": "https://images.shiksha.ws/pwa/public/images/college-predictor-icons.svg"
  },
  {
    "revision": "ee6b1fae9f7bfa073dc5677a577e2006",
    "url": "https://images.shiksha.ws/pwa/public/images/ctp-img.jpg"
  },
  {
    "revision": "e0fcc9080bb4859ca7564cc562105d04",
    "url": "https://images.shiksha.ws/pwa/public/images/default_placement_min.jpg"
  },
  {
    "revision": "6d79f5a8b38e503f4eb87112d04f26b3",
    "url": "https://images.shiksha.ws/pwa/public/images/default-College.jpg"
  },
  {
    "revision": "3ad212d6635b2b12ed659eeba491677c",
    "url": "https://images.shiksha.ws/pwa/public/images/default-event-image.jpg"
  },
  {
    "revision": "de873270f1b81e350f50fad77fa42bf6",
    "url": "https://images.shiksha.ws/pwa/public/images/desktop-banner-new.jpg"
  },
  {
    "revision": "ec7015b5d18b430ff4fcef94f7256042",
    "url": "https://images.shiksha.ws/pwa/public/images/desktop/desktop_institute_bg.jpg"
  },
  {
    "revision": "69907648e434f709c82eb733c66483cf",
    "url": "https://images.shiksha.ws/pwa/public/images/desktop/inlineRegistration.jpg"
  },
  {
    "revision": "22264969c1a6d01dc60187c01530c371",
    "url": "https://images.shiksha.ws/pwa/public/images/desktop/ShikshaMobileLoader.gif"
  },
  {
    "revision": "1ad6fa519d7b27cbef89f1542004a0b1",
    "url": "https://images.shiksha.ws/pwa/public/images/gallery_new.svg"
  },
  {
    "revision": "8ff517679987c01cf262afdc42aea01b",
    "url": "https://images.shiksha.ws/pwa/public/images/Group.svg"
  },
  {
    "revision": "b4d7728eb2966a6340a210a7be004d9c",
    "url": "https://images.shiksha.ws/pwa/public/images/hamburger.gif"
  },
  {
    "revision": "82f3df492b4f5abc7405bc1ddce5764e",
    "url": "https://images.shiksha.ws/pwa/public/images/ins-img.jpg"
  },
  {
    "revision": "ae06cebd6a4d95d37bae6f56d71ab9d6",
    "url": "https://images.shiksha.ws/pwa/public/images/mhome-icons-sprite_3.svg"
  },
  {
    "revision": "ae06cebd6a4d95d37bae6f56d71ab9d6",
    "url": "https://images.shiksha.ws/pwa/public/images/mhome-icons-sprite_4.svg"
  },
  {
    "revision": "d53d8865fca97bd6dadf2ab09ddc98e5",
    "url": "https://images.shiksha.ws/pwa/public/images/mobile_institute_bg.jpg"
  },
  {
    "revision": "407fe2189999cffd6e338309383022e7",
    "url": "https://images.shiksha.ws/pwa/public/images/notification.gif"
  },
  {
    "revision": "3382e27dfe8e1007d08d9804b7d2fdff",
    "url": "https://images.shiksha.ws/pwa/public/images/pwa-header-mobile-v2.svg"
  },
  {
    "revision": "8de89b76b47b23e81b4ccab32d2a379e",
    "url": "https://images.shiksha.ws/pwa/public/images/pwa-header-mobile-v3.svg"
  },
  {
    "revision": "3843488b0c245aa5015574f7381121f4",
    "url": "https://images.shiksha.ws/pwa/public/images/pwa-header-mobile-v4.svg"
  },
  {
    "revision": "b3ad7f6e732e8f02e8e0deed9bea4646",
    "url": "https://images.shiksha.ws/pwa/public/images/pwa-header-mobile.svg"
  },
  {
    "revision": "6fea6990526113cb0ff2fd07a6b3d7b0",
    "url": "https://images.shiksha.ws/pwa/public/images/pwa-mobile-facilities-icons.svg"
  },
  {
    "revision": "5fbaa316a484745ba90012871460740b",
    "url": "https://images.shiksha.ws/pwa/public/images/quote_opner.svg"
  },
  {
    "revision": "a5eb1f31a178c6528912b444240ddbdc",
    "url": "https://images.shiksha.ws/pwa/public/images/review-form-icons.svg"
  },
  {
    "revision": "b37b9982f9d9480e4126a31e356b4fab",
    "url": "https://images.shiksha.ws/pwa/public/images/SearchSpriteV1.svg"
  },
  {
    "revision": "22264969c1a6d01dc60187c01530c371",
    "url": "https://images.shiksha.ws/pwa/public/images/ShikshaMobileLoader.gif"
  },
  {
    "revision": "058cb0b4da480a44ce5053496c2ffb6a",
    "url": "https://images.shiksha.ws/pwa/public/images/social_shring-02.svg"
  },
  {
    "revision": "fa6d95acfdde3ad3274938c7e09f25fa",
    "url": "https://images.shiksha.ws/pwa/public/images/srp_sprite.svg"
  },
  {
    "revision": "b88d2b37ccac04a496cd4ff035ff1e0b",
    "url": "https://images.shiksha.ws/pwa/public/images/star.svg"
  },
  {
    "revision": "424ef4e030c86e2960f22a4c623d7f87",
    "url": "https://images.shiksha.ws/pwa/public/images/verified-icon.svg"
  },
  {
    "revision": "28a823f959827749ddead29567091538",
    "url": "/pwa/public/js/rankingPageMobile.9397d930be2762cdc0f8.css"
  },
  {
    "revision": "9affd4fcaebbc0f3a4ef3f25fd9d3d9b",
    "url": "/pwa/public/js/mobile.0594a90b34ab380c3b54.css"
  },
  {
    "revision": "a8dbc63fd87903396f9ae29a622db644",
    "url": "/pwa/public/js/mobile-shiksha-main-460ce46fe3cc85b631ee.js"
  },
  {
    "revision": "335a2416bcd6153bfbb36af3b2fef5e0",
    "url": "/pwa/public/js/institutedetaildesktop.300d3ee654ff08e2086d.js"
  },
  {
    "revision": "a73cde318ea0c1f80b7851ab52bcf8f8",
    "url": "/pwa/public/js/institutedetaildesktop.2ff16ed9bbe739cd831c.css"
  },
  {
    "revision": "5caccf3de5f28d54459fe1652c0c65c1",
    "url": "/pwa/public/js/institutedetail.e8ce71fe1b24757b6de6.js"
  },
  {
    "revision": "2ddcdf9e0c48cf57134ee27e64029b8b",
    "url": "/pwa/public/js/institutedetail.47e53aab105fab097963.css"
  },
  {
    "revision": "611cff9432b34e27055877bbc97abefa",
    "url": "/pwa/public/js/homepage.93fd4a7a66929a38592f.js"
  },
  {
    "revision": "537a31c39954a88653142a670834bfb8",
    "url": "/pwa/public/js/homepage.36a2a8c47e40b8d72298.css"
  },
  {
    "revision": "faf74b08b0d743323d17c2f7be429287",
    "url": "/pwa/public/js/hamburger.ad679fa5355de3fb4e4a.js"
  },
  {
    "revision": "c4e6fa23753e4192422d787d270adfd5",
    "url": "/pwa/public/js/hamburger.22b48470afec9849a997.css"
  },
  {
    "revision": "34702771ab26c6800cc8576bd7dbb1f4",
    "url": "/pwa/public/js/footer.6dbdb5d6f261e6d2a561.js"
  },
  {
    "revision": "237a88e474c28e511c88fd51e51e1d24",
    "url": "/pwa/public/js/examPage.b7a538b8f17f0201dbc1.css"
  },
  {
    "revision": "94cbb4b1dcdc868fb9984f99a7f7fed4",
    "url": "/pwa/public/js/examPage.922339a01749435342ce.js"
  },
  {
    "revision": "8804e79772260bf85875576cf47dc1ef",
    "url": "/pwa/public/js/dummyLayer.ee4585ba92bc10cedf4d.js"
  },
  {
    "revision": "9a5be0f26d989c13fdf7338d703e173a",
    "url": "/pwa/public/js/dummyLayer.13769b2fdc2ead860b69.css"
  },
  {
    "revision": "9e2a021f3b8d653618be37285f515967",
    "url": "/pwa/public/js/desktopSearchLayer.c03cb8704b21f64304b8.js"
  },
  {
    "revision": "443fc400493da172876f8368cff0d2db",
    "url": "/pwa/public/js/desktopQNALayer.ef2d0b86e32c9e3f689a.css"
  },
  {
    "revision": "6228471f86bdf8f126dfe15748d7dfdf",
    "url": "/pwa/public/js/desktopQNALayer.45e4c99667eaa5fd8c03.js"
  },
  {
    "revision": "9affd4fcaebbc0f3a4ef3f25fd9d3d9b",
    "url": "/pwa/public/js/desktop.0594a90b34ab380c3b54.css"
  },
  {
    "revision": "3c9d69875930048829a02ba67dafd84b",
    "url": "/pwa/public/js/desktop-shiksha-main-460ce46fe3cc85b631ee.js"
  },
  {
    "revision": "c350572b723f3ae0f47daf3f1e024a16",
    "url": "/pwa/public/js/courseHomePage.f5b77710db240df72338.css"
  },
  {
    "revision": "57cad3f467c98dca01a5050b0e943f4c",
    "url": "/pwa/public/js/courseHomePage.8b79e4f6ca68b87bb54d.js"
  },
  {
    "revision": "7eac96b9c0f1f5cdc81901b7ec6bc777",
    "url": "/pwa/public/js/coursedetail.702b4062a61c1affab53.js"
  },
  {
    "revision": "e767332ae23194701b5053c543cbebff",
    "url": "/pwa/public/js/categorypage.49fd8ee079efce9be8db.css"
  },
  {
    "revision": "93a3b0ab89ad44a430f9e958bf20af36",
    "url": "/pwa/public/js/categorypage.c719b1e284824b44a22d.js"
  },
  {
    "revision": "f3f8bc8233317fe2dd9b76033ff32e66",
    "url": "/pwa/public/js/coursedetail.0dbde78a67363b889565.css"
  },
  {
    "revision": "42b511144862705ba5cb72ca18b26d64",
    "url": "/pwa/public/js/AllChildPage.942c8b61aa319c8070a9.css"
  },
  {
    "revision": "c072cd1d0b43c5d518243249e290ac23",
    "url": "/pwa/public/js/CategoryTuple.b1deaae895fd64da0131.js"
  },
  {
    "revision": "52934c91c5055c9c3c7c6110813e33ba",
    "url": "/pwa/public/js/CollegePredictorDesktop.a2fb6c4ee621bf8d1fa1.css"
  },
  {
    "revision": "52934c91c5055c9c3c7c6110813e33ba",
    "url": "/pwa/public/js/CollegePredictorMobile.a2fb6c4ee621bf8d1fa1.css"
  },
  {
    "revision": "86d15633e9155407113b4878f07ed540",
    "url": "/pwa/public/js/SRPNavBar.ea63c3bf693c02aa55d5.css"
  },
  {
    "revision": "b836fc9386a47c4b3d6b30b224508677",
    "url": "/pwa/public/js/CollegePredictorResultsDesktop.12a8b397c580486a2206.css"
  },
  {
    "revision": "22264d78197ad1d3536f8bad6ef0e9d2",
    "url": "/pwa/public/js/CollegePredictorResultsDesktop.642d9fbdf1ab0ebf720b.js"
  },
  {
    "revision": "41cd940ec18ae59a3f5db9b2a3b7775b",
    "url": "/pwa/public/js/CollegePredictorResultsMobile.19ed931d9e353613bb59.css"
  },
  {
    "revision": "f471078b46ef2c0b67ecc0fb23b72257",
    "url": "/pwa/public/js/CollegePredictorResultsMobile.751c06e42da2fe3af6cb.js"
  },
  {
    "revision": "cb40d08c5f74b2bc8f5bc699c365bc18",
    "url": "/pwa/public/js/SRPNavBar.df318ab8b6243d0f233b.js"
  },
  {
    "revision": "76e2e4a3a1656e556bf8a8dd283c47d1",
    "url": "/pwa/public/js/SocialSharing.cf985ad4d30e3b62d08a.js"
  },
  {
    "revision": "3f948deb4bd5429dd8e5f0d2b6eca89d",
    "url": "/pwa/public/js/SocialSharing.ba625804b00b16e562ac.css"
  },
  {
    "revision": "9ce0a9182131507ceb3e004f6b9d3669",
    "url": "/pwa/public/js/ResponseForm.4566a6d6483a15c724d2.js"
  },
  {
    "revision": "1d3d366327495da1f7625074bed8cce6",
    "url": "/pwa/public/js/CourseHomePageDesktop.0b6ea6b3c18a79a5d2af.js"
  },
  {
    "revision": "311077362d5931dade79df2b77bad818",
    "url": "/pwa/public/js/CourseHomePageDesktop.c314d8ada554a3ffb58e.css"
  },
  {
    "revision": "f33f8f42382a7f47b72079e1482adc88",
    "url": "/pwa/public/js/CutoffPage.3ad1b53440185ba8c965.js"
  },
  {
    "revision": "13fd4e1957b1725ef751761f23c9a7c1",
    "url": "/pwa/public/js/CutoffPage.e03ea68720bd46909d1f.css"
  },
  {
    "revision": "944f00f7d0f1b3c75dc557f6c1f22fe8",
    "url": "/pwa/public/js/CutoffPageDesktop.ce6ee89a79ccdac51085.css"
  },
  {
    "revision": "017faa4b687c1d104ecbb126dc3c9696",
    "url": "/pwa/public/js/CutoffPageDesktop.f80014336d5bfba685ed.js"
  },
  {
    "revision": "9a5be0f26d989c13fdf7338d703e173a",
    "url": "/pwa/public/js/ResponseForm.13769b2fdc2ead860b69.css"
  },
  {
    "revision": "16d5c5e4ceadd25993473236bafa5b34",
    "url": "/pwa/public/js/RecommendationPage.d8c5ebe4fbdfeff908d8.css"
  },
  {
    "revision": "94a230114d11af18c37303a7290ff967",
    "url": "/pwa/public/js/DesktopCTP.15312f830e5812e2a22a.css"
  },
  {
    "revision": "66374699085a3cc6d680aa4b0f6bbd6e",
    "url": "/pwa/public/js/DesktopCTP.42016b6f18c3230b68f3.js"
  },
  {
    "revision": "bc526609faabaf3c00fb03d1c76019a9",
    "url": "/pwa/public/js/RecommendationPage.1f3b20e793ae11e35393.js"
  },
  {
    "revision": "733c8f9a006787ab83e96febeca610ba",
    "url": "/pwa/public/js/RankingPageDesktop.827cdb46996513f957e5.js"
  },
  {
    "revision": "7f6851b6f9b58b207ded49a2e3a4ae5b",
    "url": "/pwa/public/js/RankingPageDesktop.0dc2eec5271267717483.css"
  },
  {
    "revision": "041cef9f583f90edd9474cead7b7c397",
    "url": "/pwa/public/js/PlacementPageDesktop.7f2ef9a8950edc4b057e.js"
  },
  {
    "revision": "b0402890509f6680d34d5cd496beef3f",
    "url": "/pwa/public/js/PlacementPageDesktop.1269045e557c01d9c518.css"
  },
  {
    "revision": "381f05901f6a4035cbdf31ab84008d35",
    "url": "/pwa/public/js/ExamBottomSticky.14173ef75bfdb5cb4069.css"
  },
  {
    "revision": "eb826b1fa3b82af7b2b04607d0d27c74",
    "url": "/pwa/public/js/ExamBottomSticky.9229f5abe52119dd36b7.js"
  },
  {
    "revision": "f04c2a2572168c97fad47aeb096f9748",
    "url": "/pwa/public/js/PlacementPage.6964511292ab8e9a57a5.js"
  },
  {
    "revision": "4ee8035394dd20deda5dcc68bd5b75a2",
    "url": "/pwa/public/js/PlacementPage.1ddfd99863f7fcec7398.css"
  },
  {
    "revision": "09e4cc8154aa3df78b6bcc736fedca52",
    "url": "/pwa/public/js/ExamPageDesktop.27da4391569b98af79c1.js"
  },
  {
    "revision": "8f2efc992377e2ce766350881f36248f",
    "url": "/pwa/public/js/ExamPageDesktop.fbe95a6c7ef923f240c4.css"
  },
  {
    "revision": "9a5be0f26d989c13fdf7338d703e173a",
    "url": "/pwa/public/js/ExamResponseForm.13769b2fdc2ead860b69.css"
  },
  {
    "revision": "41068a7fda35cbbc4f78abdd2b01121f",
    "url": "/pwa/public/js/ExamResponseForm.87d1ffca48941c893cd3.js"
  },
  {
    "revision": "7173c249e4ce904a77f14aa1ffe7a241",
    "url": "/pwa/public/js/ExamSrp.4162c195d838213743eb.js"
  },
  {
    "revision": "e10f32b1db348d389c783c0d7c314072",
    "url": "/pwa/public/js/ExamSrp.c9754b79fc1bf5fb777a.css"
  },
  {
    "revision": "ea031b0d608a60d5a669e1ba4d8a23a4",
    "url": "/pwa/public/js/FeedbackForm.a55803deffa67d5a5794.css"
  },
  {
    "revision": "e1f4cbc59cf8e6b0594daae2801a4032",
    "url": "/pwa/public/js/FeedbackForm.f6bce588de4dbc674b32.js"
  },
  {
    "revision": "9c5b7d43fdae24af3bd7d40fd1075969",
    "url": "/pwa/public/js/FiltersComponent.8078bfbd3efcfbc42d8f.js"
  },
  {
    "revision": "b5c4a365cc9190dcc496e9742d444a47",
    "url": "/pwa/public/js/FiltersComponent.f174e0438bd67c10bc82.css"
  },
  {
    "revision": "8c4953dcd5c74d1b1ff36b645012c07c",
    "url": "/pwa/public/js/PlacementComponent.e457530dd82dbc18f5a3.css"
  },
  {
    "revision": "1821f883b7d2c4a4787c4b75ce3c558f",
    "url": "/pwa/public/js/PlacementComponent.2356c28d1fe42227bcab.js"
  },
  {
    "revision": "41bac9777908808a6e2df1c768fb5597",
    "url": "/pwa/public/js/CollegePredictorDesktop.57bc93022bb59327c323.js"
  },
  {
    "revision": "a2cdb798ad81ebf1edf18b1ddfaf7929",
    "url": "/pwa/public/js/OCF.73d10fe84b378eede9f6.js"
  },
  {
    "revision": "5bbee309165eb29a6755f2fe7661daae",
    "url": "/pwa/public/js/OCF.552cf2bc920b0e28e302.css"
  },
  {
    "revision": "0f77171a9c2d99688550ab25e7eb39ef",
    "url": "/pwa/public/js/HomePageDesktop.ad19fa4a45156af9c1eb.css"
  },
  {
    "revision": "994a8015cf89ddf0fcfc60a119cc2747",
    "url": "/pwa/public/js/HomePageDesktop.d74c6e33429d7c26541b.js"
  },
  {
    "revision": "6982e74c3869415698afdc343d91fd7d",
    "url": "/pwa/public/js/NaukriPlacementComponent.fcf4d2b949b11494c75b.js"
  },
  {
    "revision": "cf623f6e47f16a2143824eb6dc2fac03",
    "url": "/pwa/public/js/NaukriPlacementComponent.8e16d38d398a62555bc3.css"
  },
  {
    "revision": "a51b08dfa2ed738ba2718c099a901a1f",
    "url": "/pwa/public/js/ListingChildPages.b33febe2b4ec2f2b791d.js"
  },
  {
    "revision": "7f9a515d0b799fb6b9fef64c794ef441",
    "url": "/pwa/public/js/ListingChildPages.74d4a59863209facb8f7.css"
  },
  {
    "revision": "d6a02a12d064cd0cff6b8a0f0dbf9ab2",
    "url": "/pwa/public/desktop-app-shell.html"
  },
  {
    "revision": "0b9df32b6da03e664a79a364824542c0",
    "url": "/pwa/public/js/AdmissionPage.e74fe4959c8201ae1b04.css"
  },
  {
    "revision": "0482c6ce3bd5d40908e003716530968c",
    "url": "/pwa/public/js/CategoryTuple.4d125d30ecdda5be4060.css"
  },
  {
    "revision": "34cc000a3d018a40ec9d40900d8cfde5",
    "url": "/pwa/public/js/BottomSticky.6bd2b78f128265d31772.js"
  },
  {
    "revision": "20573726ae42da81112a526e116864df",
    "url": "/pwa/public/js/AdmissionPageDesktop.a8c01e1af5338b52f8db.js"
  },
  {
    "revision": "b91c6470cc91ed0389ec74efde902ac0",
    "url": "/pwa/public/js/AdmissionPdf.9435ae5554f8e9a91830.css"
  },
  {
    "revision": "6127c0e2008cff134c210342ee14c2a4",
    "url": "/pwa/public/js/AdmissionPdf.ea5e6b28ece67a5ba595.js"
  },
  {
    "revision": "f2f87ef730f1fc3a831a42991ebfb95d",
    "url": "/pwa/public/js/AllChildPage.693e972810a64eddb195.js"
  },
  {
    "revision": "8f52aef440d8dde969ecd95f4f7d4069",
    "url": "/pwa/public/js/BottomSticky.17440dfed368a49062fa.css"
  },
  {
    "revision": "14032b8d49bff777a7c34492bd69ee5c",
    "url": "/pwa/public/js/BackTop.da4fcb0378ef86a0ada6.css"
  },
  {
    "revision": "59a3bafdfeb79686827ed5331543120d",
    "url": "/pwa/public/js/AllCoursePageDesktop.d2f6e02901824f645f37.css"
  },
  {
    "revision": "e4a607d301d52c0b82f336ef8fc85b59",
    "url": "/pwa/public/js/AllCoursePageDesktop.efa37e5937453bb2b044.js"
  },
  {
    "revision": "3a5440565a99300a42f051b008ca33ab",
    "url": "/pwa/public/js/AllCoursePdf.456536c25da6003795c6.css"
  },
  {
    "revision": "e14767c989d2f7cc33761bbe6b32e5bf",
    "url": "/pwa/public/js/AllCoursePdf.9b330c0c7ae68dd49ab5.js"
  },
  {
    "revision": "313502d2b5fc3416006f51e668677784",
    "url": "/pwa/public/js/AllExamPageDesktop.b8d574e3320b9d0f1b8c.css"
  },
  {
    "revision": "bc2f0789fc4fb0a480fac632b7eaeda1",
    "url": "/pwa/public/js/AllExamPageDesktop.ca35daf7937e99880cf9.js"
  },
  {
    "revision": "85a6d9eec8c0410cdb2d9b02c885facc",
    "url": "/pwa/public/js/BackTop.31d914d4dad56537c8fd.js"
  },
  {
    "revision": "d1eaac7a08c42541f71d756e4ac2ab02",
    "url": "/pwa/public/js/AllExamPageMobile.c3a816e12095484c78fa.js"
  },
  {
    "revision": "fe459aa17edc57ed7db95c5e35c2534b",
    "url": "/pwa/public/js/AdmissionPageDesktop.1c891d83b04c64df717e.css"
  },
  {
    "revision": "7881207b9f2c84f49ed0c4baa49c13ee",
    "url": "/pwa/public/js/AllExamPageMobile.a67cdb3dfe0a014b8460.css"
  },
  {
    "revision": "3a5440565a99300a42f051b008ca33ab",
    "url": "/pwa/public/js/ALLCOURSEPAGE.456536c25da6003795c6.css"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/pwa/public/css/shikshaDesktopCommon.css"
  },
  {
    "revision": "8a81a8563c3eabc9f09fbd0fe3334c34",
    "url": "/pwa/public/js/7.532674f6ae9c3e1f498b.css"
  },
  {
    "revision": "235d967ed4006f00a23ee6bbf93bfae6",
    "url": "/pwa/public/js/ALLCOURSEPAGE.88c95029cbc7a25e77fb.js"
  },
  {
    "revision": "ff3ee31f1b2c9f14e2c69240095cb6d2",
    "url": "/pwa/public/js/AdmissionPage.5b9363113cc81701dda6.js"
  },
  {
    "revision": "2626287dd59e5dbce767aad2b4912d6f",
    "url": "/pwa/public/js/7.9d9ea3cb91d0d7792118.js"
  },
  {
    "revision": "458d3cbe4d617b0d031801deb644f00f",
    "url": "/pwa/public/extra_js_bk/registrationCallbacks.js"
  },
  {
    "revision": "8427eb355c53d4e21ec4a9bfb616e1c7",
    "url": "/pwa/public/css/shikshaCommon.css"
  },
  {
    "revision": "a20474aaf1460a0322e6445b65abcfc4",
    "url": "/pwa/public/css/index_desktop_css.css"
  },
  {
    "revision": "2406cd83645047d7f40cc0f564c4497d",
    "url": "/pwa/public/css/index_css.css"
  },
  {
    "revision": "5a9344adc4f99903f91d93f1433c5a1e",
    "url": "/pwa/public/css/firstFold/mobile/inline_exampage.css"
  },
  {
    "revision": "4616728ecd4215b89d71bdb008de8e89",
    "url": "/pwa/public/css/firstFold/mobile/inline_collegepredictor.css"
  },
  {
    "revision": "b15362d34a52f8c982f3e82d5a94d86d",
    "url": "/pwa/public/css/firstFold/desktop/inline_homepage.css"
  },
  {
    "revision": "9ec73b39eb8920b183e3cb202f48cc92",
    "url": "/pwa/public/css/dfp/mobile-dfp-promotion-banner.css"
  },
  {
    "revision": "b64a2b22b1ffedd42888c98774e1d718",
    "url": "/pwa/public/css/dfp/desktop-dfp-promotion-banner.css"
  },
  {
    "revision": "fae34ad6310e6df7dfe69edd149da41c",
    "url": "/pwa/public/app-shell.html"
  }
];